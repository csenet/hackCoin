const app = require('./app')

app.listen(3000, (req) => {
  console.log('listening');
})
